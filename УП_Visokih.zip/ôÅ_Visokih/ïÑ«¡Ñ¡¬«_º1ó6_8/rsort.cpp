using namespace std;
void rsort(int* array, int size)
{
	if (!array || !size)
		return;
	int jump = size;
	int q = 1;
	bool swapped = true;

	while (jump > 1 || swapped)
	{
		if (jump > 1)
			jump = (int)(jump / 1.25);
		swapped = false;
		for (int i = 0; i + jump < size; i++)
			if (array[i] > array[i + jump])
			{
				int temp = array[i];
				array[i] = array[i+jump];
				array[i+jump] = temp;
				swapped = true;
			}		
	}
	
}