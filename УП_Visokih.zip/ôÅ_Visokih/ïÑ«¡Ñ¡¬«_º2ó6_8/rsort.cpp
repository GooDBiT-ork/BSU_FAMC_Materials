extern long int  sr, per;
using namespace std;
void rsort(int* array, int size)
{
	if (!array || !size)
		return;
	int jump = size;
	bool swapped = true;
	while (jump > 1 || swapped)
	{
		sr++;
		if (jump > 1)
			jump = (int)(jump / 1.25);
		swapped = false;
		for (int i = 0; i + jump < size; i++)
		{
			sr++;
			if (array[i] > array[i + jump])
			{
				per++;
				int temp = array[i];
				array[i] = array[i + jump];
				array[i + jump] = temp;
				swapped = true;
			}
		}
	}
	
}