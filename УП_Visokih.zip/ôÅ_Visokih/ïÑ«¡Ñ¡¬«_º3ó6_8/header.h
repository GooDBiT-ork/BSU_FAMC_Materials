#pragma once
#ifndef header
#define header
void rsort(int*, int);
void ShakerSort(int*, int);
int InputGen(int &size);
int RandGen(int& size);
int *FileGen(int& size);
#endif