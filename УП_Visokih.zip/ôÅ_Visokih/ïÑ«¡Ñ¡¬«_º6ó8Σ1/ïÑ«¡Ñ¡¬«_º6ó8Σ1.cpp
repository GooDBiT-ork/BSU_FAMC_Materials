#include<iostream>
#include<fstream>
#include<iomanip>
using namespace std;
struct Info
{
	int x, y;
};
struct ListItem
{
	int x, y;
	ListItem* next;
};
struct Q
{
	ListItem* front;
	ListItem* rear;
	int size;
};
void create(Q& q)
{
	q.front = q.rear = NULL;
	q.size = 0;
}
bool empty(const Q& q)
{
	return (q.size == 0);
}
void push(Q& q, int xx, int yy)
{
	ListItem* temp = new ListItem;
	temp->x = xx;
	temp->y = yy;
	if (q.size > 0)
		q.rear->next = temp;
	else
		q.front = temp;
	q.rear = temp;
	q.size++;
}
Info pop(Q& q)throw(char*)
{
	if (empty(q))
		throw"Queue is empty!";
	Info inf;
	inf.x = q.front->x;
	inf.y = q.front->y;
	ListItem* temp = q.front;
	q.front = q.front->next;
	delete temp;
	q.size--;
	if (q.size == 0)
		q.rear = NULL;
	return inf;
}
int calculate(int**a, int m, int n, int xs, int ys, int xf, int yf)
{
	int di[4] = { -1, 0, 1,  0 };
	int dj[4] = { 0, 1, 0, -1 };
	int i, j;
	int** d = new int* [m];
	for (int i = 0; i < m; i++)
	{
		d[i] = new int[n];
	}
	for (i = 0; i < m; i++)
		for (j = 0; j < n; j++)
			d[i][j] = 0;
	d[xs][ys] = 1;
	Q q;
	create(q);
	push(q, xs, ys);
	try
	{
		while (!empty(q))
		{
			Info p = pop(q);
			for (int k = 0; k < 4; k++)
			{
				Info newp;
				newp.x = p.x + di[k];
				newp.y = p.y + dj[k];

				if ((0 <= newp.x) && (newp.x < m) && (0 <= newp.y) && (newp.y < n))
					if ((a[p.x][p.y] > a[newp.x][newp.y])&& (d[newp.x][newp.y] == 0))
					{
						d[newp.x][newp.y] = d[p.x][p.y] + 1;
						push(q, newp.x, newp.y);
					}
			}
		}
	}
	catch (char* s)
	{
		cout << s << endl;
	}
	int res = d[xf][yf];
	for (int i = 0; i < m; i++)
		delete[] d[i];
	delete[] d;
	if (res)
		return --res;
	else
		return -100;
}
int main()
{
	setlocale(LC_ALL, ".1251");
	ifstream in("��������_�6�8�2.txt");
	if (!in)
	{
		cout << "File no find!" << endl;
		return 0;
	}
	int m = 0, n = 0;
	if (!(in >> m))
	{
		in.close();
		cout << "Not enough dates!" << endl;
		return 0;
	}
	if (!(in >> n))
	{
		in.close();
		cout << "Not enough dates!" << endl;
		return 0;
	}
	int** a = new int* [m];
	for (int i = 0; i < m; i++)
		a[i] = new int[n];
	for (int i = 0; i < m; i++)
		for (int j = 0; j < n; j++)
		{
			if (!(in >> a[i][j]))
			{
				in.close();
				cout << "Not enough dates!" << endl;
				return 0;
			}
		}
	cout << " m = " << m << ", n = " << n << endl;
	for (int i = 0; i < m; i++)
	{
		for (int j = 0; j < n; j++)
			cout <<setw(6)<< a[i][j];
		cout << endl;
	}
	int xs = 0, ys = 0, xf = 0, yf = 0;
	cout << "Rules:" << endl;
	cout << "1. If XStart = XFinish and YStart = YFinish - result = 0" << endl;
	cout << "2. XStart and XFinish - I-index of array(0 <= and <  m), YStart and YFinish - J-index of array(0 <= and < n" << endl;
	cout << "XStart = ";
	cin >> xs;
	cout << "YStart = ";
	cin >> ys;
	cout << "XFinish = ";
	cin >> xf;
	cout << "YFinish = ";
	cin >> yf;
	cout << endl;
	int res = calculate(a, m, n, xs, ys, xf, yf);
	if (res == -100)
		cout << "Impossible to reach the finish point!" << endl;
	else
		cout << "Result = " << res << endl;
	in.close();
	for (int i = 0; i < m; i++)
	delete[] a[i];
	delete[] a;
	return 0;

	return 0;
}